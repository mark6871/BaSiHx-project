for((i=0;i<=9;i++))
do
	python3 poscar2cif xx0${i} 0.5 5 > hull_${i}.cif
done

for((i=10;i<=40;i++))
do
	python3 poscar2cif xx${i} 0.5 5 > hull_${i}.cif
done
